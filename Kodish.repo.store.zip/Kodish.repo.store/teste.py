import nitse

data = "\x74\x72\x75\x73\x74"
print(nitse.nitseffw(data))
