# -*- coding: cp1252 -*-
# -*- coding: utf-8 -*-

import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,sys
import shutil
import urllib2,urllib
import re
import extract
import time
import downloader
import plugintools
import zipfile
import ntpath
import ssl
import base64
import traceback,sys
from libs import kodi
from libs import viewsetter


icon = os.path.join(xbmc.translatePath("special://home/addons/Kodish.repo.store/icon.png").decode("utf-8"))

if kodi.get_kversion() >16.5:
	#kodi.log(' VERSION IS ABOVE 16.5')
	ssl._create_default_https_context = ssl._create_unverified_context
else:
	#kodi.log(' VERSION IS BELOW 16.5')
	pass
from libs import addon_able


USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
base='http://kodish.esy.es'
ADDON=xbmcaddon.Addon(id='Kodish.repo.store')
addon = ADDON     
    
VERSION = "1.0.2"
PATH = "kodish.esy.es"


                
def controladdon(): 
		tw = "PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9InllcyI/Pgo8YWRkb24gaWQ9InJlcG8uVFdUVVRPUklBSVMiIG5hbWU9Ii1bQl1bQ09MT1Igd2hpdGVdLlsvQ09MT1JdW0NPTE9SIG1lZGl1bWJsdWVdTUVHQVsvQ09MT1JdW0NPTE9SIGxpbWVdIFJFUE9bL0NPTE9SXVtDT0xPUiB5ZWxsb3ddIFRXVHV0b3JpYWlzWy9CXVsvQ09MT1JdLSIgdmVyc2lvbj0iNS4wIiBwcm92aWRlci1uYW1lPSJyZXBvLlRXVFVUT1JJQUlTIj4KPHJlcXVpcmVzPgogICAgPGltcG9ydCBhZGRvbj0ieGJtYy5weXRob24iIHZlcnNpb249IjIuMS4wIi8+CiAgICA8aW1wb3J0IGFkZG9uPSJzY3JpcHQubW9kdWxlLmJlYXV0aWZ1bHNvdXAiIHZlcnNpb249IjMuMi4xIi8+CiAgICA8aW1wb3J0IGFkZG9uPSJzY3JpcHQubW9kdWxlLnNpbXBsZS5kb3dubG9hZGVyIiB2ZXJzaW9uPSIwLjkuNCIvPgogICAgPGltcG9ydCBhZGRvbj0ic2NyaXB0Lm1vZHVsZS50MG1tMC5jb21tb24iIHZlcnNpb249IjIuMC4wIi8+CiAgICA8aW1wb3J0IGFkZG9uPSJzY3JpcHQubW9kdWxlLmJlYXV0aWZ1bHNvdXA0IiAvPgogICAgPGltcG9ydCBhZGRvbj0ic2NyaXB0Lm1vZHVsZS5yZXF1ZXN0cyIgLz4KICAgIDxpbXBvcnQgYWRkb249InNjcmlwdC5tb2R1bGUuaHR0cGxpYjIiIC8+CiAgICA8aW1wb3J0IGFkZG9uPSJzY3JpcHQubW9kdWxlLnNpbXBsZS5kb3dubG9hZGVyIiB2ZXJzaW9uPSIwLjkuNCIvPgogICAgPGltcG9ydCBhZGRvbj0ic2NyaXB0Lm1vZHVsZS51cmxyZXNvbHZlciIgLz4KICAgIDxpbXBvcnQgYWRkb249InNjcmlwdC5tb2R1bGUuc2ltcGxlanNvbiIgLz4gICAgCiAgICA8aW1wb3J0IGFkZG9uPSJzY3JpcHQubW9kdWxlLmxpdmVzdHJlYW1lciIvPgogICAgPGltcG9ydCBhZGRvbj0ic2NyaXB0Lm1vZHVsZS5weWFtZiIvPgogICAgPGltcG9ydCBhZGRvbj0ic2NyaXB0LmNvbW1vbi5wbHVnaW4uY2FjaGUiIHZlcnNpb249IjIuNS4yIi8+CiAgICA8aW1wb3J0IGFkZG9uPSJzY3JpcHQubW9kdWxlLm1ldGFoYW5kbGVyIiB2ZXJzaW9uPSIyLjUuMSIvPgoJPGltcG9ydCBhZGRvbj0ic2NyaXB0Lm1vZHVsZS5hZGRvbi5jb21tb24iIC8+Cgk8aW1wb3J0IGFkZG9uPSJzY3JpcHQubW9kdWxlLmFkZG9uLnNpZ25hbHMiIHZlcnNpb249IjAuMC4xIi8+Cgk8aW1wb3J0IGFkZG9uPSJzY3JpcHQubW9kdWxlLnlvdXR1YmUuZGwiLz4KPC9yZXF1aXJlcz4KCTxleHRlbnNpb24gcG9pbnQ9InhibWMuYWRkb24ucmVwb3NpdG9yeSIgbmFtZT0iUmVwb3NpdG9yaW8gVFdUdXRvcmlhaXMiPgoJCTxpbmZvIGNvbXByZXNzZWQ9ImZhbHNlIj5odHRwczovL3Jhdy5naXRodWJ1c2VyY29udGVudC5jb20va29kaXNobWVkaWFjZW50ZXIvb21lZ2EvbWFzdGVyL3R3L2FkZG9ucy54bWw8L2luZm8+CgkJPGNoZWNrc3VtPmh0dHBzOi8vcmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbS9rb2Rpc2htZWRpYWNlbnRlci9vbWVnYS9tYXN0ZXIvdHcvdHctbWQ1Lm1kNTwvY2hlY2tzdW0+CgkJPGRhdGFkaXIgemlwPSJ0cnVlIj5odHRwczovL3Jhdy5naXRodWJ1c2VyY29udGVudC5jb20vQlVJTERUT05ZV0FSTExFWS9SRVBPVFdUVVRPUklBSVMvbWFzdGVyL1BsdWdpbnMvPC9kYXRhZGlyPgoJPC9leHRlbnNpb24+Cgk8ZXh0ZW5zaW9uIHBvaW50PSJ4Ym1jLmFkZG9uLm1ldGFkYXRhIj4KCSAgPG5ld3M+CltDT0xPUiB3aGl0ZV1BZGQtb24gSU5TVEFMQURPIFZJQSBSRVBPIE1FR0FSRVBPIFRXVFVUT1JJQUlTLCBuw6NvIGJhaXhlIEFkZC1vbnMgcXVlIG7Do28gc2VqYW0gT2ZpY2lhbCwgQWRkLW9ucyBPZmljaWFpcyBzb21lbnRlIG5hIE1FR0FSRVBPLlsvQ09MT1JdCgoKW0NPTE9SIGxpbWVdRSBvIFBhbG1laXJhcyBuw6NvIHRlbSBNdW5kaWFsWy9DT0xPUl0KICAgICAgICA8L25ld3M+CgkJPHN1bW1hcnk+UmVwb3NpdG9yaW8gTUVHQVJFUE8gVFdUdXRvcmlhaXM8L3N1bW1hcnk+CgkJPGRlc2NyaXB0aW9uPltDT0xPUiBtZWRpdW1ibHVlXUFkZC1vbiBJTlNUQUxBRE8gVklBIFJFUE8gTUVHQVJFUE8gVFdUVVRPUklBSVMsIG7Do28gYmFpeGUgQWRkLW9ucyBxdWUgbsOjbyBzZWphbSBPZmljaWFsLCBBZGQtb25zIE9maWNpYWlzIHNvbWVudGUgbmEgTUVHQVJFUE8uWy9DT0xPUl0KW0NPTE9SIGxpbWVdW0JdUmVwb3NpdMOzcmlvIE1FR0FSRVBPIFRXVHV0b3JpYWlzIC0gUHJvaWJpZGEgQ8OzcGlhIGUgUmVwcm9kdcOnw6NvIHNlbSBBdXRvcml6YcOnw6NvLlsvQl1bL0NPTE9SXQoKW0NPTE9SIHllbGxvd11RdWUgRMOTIGRhcyBmb3JtaWd1aW5oYXMuLi5ra2sKTnVuY2EgU2Vyw6NvLCBKYW1haXMgU2Vyw6NvIVsvQ09MT1JdCgkJPC9kZXNjcmlwdGlvbj4KCQk8ZGlzY2xhaW1lcj48L2Rpc2NsYWltZXI+CgkJPHBsYXRmb3JtPmFsbDwvcGxhdGZvcm0+Cgk8L2V4dGVuc2lvbj4KPC9hZGRvbj4="
		vk = "PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9InllcyI/Pgo8YWRkb24gaWQ9InJlcG8udmlraW5ncyIgbmFtZT0iW0JdW0NPTE9SIHllbGxvd10gIFZpa2luZ3MgIFtDT0xPUiBvcmFuZ2VdUmVwb3NpdG9yaW8gVmlraW5ncyBPZmljaWFsLCBTRU0gQkFOSU1FTlRPISFbL0JdWy9DT0xPUl0iIAp2ZXJzaW9uPSIxLjE2IiAKcHJvdmlkZXItbmFtZT0iVmlraW5ncyBURUFNIj4iPgoJPHJlcXVpcmVzPgogICAgPGltcG9ydCBhZGRvbj0ieGJtYy5weXRob24iIHZlcnNpb249IjIuMS4wIi8+CiAgICA8aW1wb3J0IGFkZG9uPSJzY3JpcHQubW9kdWxlLmJlYXV0aWZ1bHNvdXAiIHZlcnNpb249IjMuMi4xIi8+CiAgICA8aW1wb3J0IGFkZG9uPSJzY3JpcHQubW9kdWxlLnNpbXBsZS5kb3dubG9hZGVyIiB2ZXJzaW9uPSIwLjkuNCIvPgogICAgPGltcG9ydCBhZGRvbj0ic2NyaXB0Lm1vZHVsZS50MG1tMC5jb21tb24iIHZlcnNpb249IjIuMC4wIi8+CiAgICA8aW1wb3J0IGFkZG9uPSJzY3JpcHQubW9kdWxlLmJlYXV0aWZ1bHNvdXA0IiAvPgogICAgPGltcG9ydCBhZGRvbj0ic2NyaXB0Lm1vZHVsZS5yZXF1ZXN0cyIgLz4KICAgIDxpbXBvcnQgYWRkb249InNjcmlwdC5tb2R1bGUuaHR0cGxpYjIiIC8+CiAgICA8aW1wb3J0IGFkZG9uPSJzY3JpcHQubW9kdWxlLnNpbXBsZS5kb3dubG9hZGVyIiB2ZXJzaW9uPSIwLjkuNCIvPgogICAgPGltcG9ydCBhZGRvbj0ic2NyaXB0Lm1vZHVsZS51cmxyZXNvbHZlciIgLz4KICAgIDxpbXBvcnQgYWRkb249InNjcmlwdC5tb2R1bGUuc2ltcGxlanNvbiIgLz4gICAgCiAgICA8aW1wb3J0IGFkZG9uPSJzY3JpcHQubW9kdWxlLmxpdmVzdHJlYW1lciIvPgogICAgPGltcG9ydCBhZGRvbj0ic2NyaXB0Lm1vZHVsZS5weWFtZiIvPgogICAgPGltcG9ydCBhZGRvbj0ic2NyaXB0LmNvbW1vbi5wbHVnaW4uY2FjaGUiIHZlcnNpb249IjIuNS4yIi8+CiAgICA8aW1wb3J0IGFkZG9uPSJzY3JpcHQubW9kdWxlLm1ldGFoYW5kbGVyIiB2ZXJzaW9uPSIyLjUuMSIvPgoJPGltcG9ydCBhZGRvbj0ic2NyaXB0Lm1vZHVsZS5hZGRvbi5jb21tb24iIC8+Cgk8aW1wb3J0IGFkZG9uPSJzY3JpcHQubW9kdWxlLmFkZG9uLnNpZ25hbHMiIHZlcnNpb249IjAuMC4xIi8+CgkKICA8L3JlcXVpcmVzPgogIDxleHRlbnNpb24gcG9pbnQ9InhibWMuYWRkb24ucmVwb3NpdG9yeSIgbmFtZT0iVmlraW5ncyBSZXBvc2l0b3J5Ij4KCQk8aW5mbyBjb21wcmVzc2VkPSJmYWxzZSI+aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2tvZGlzaG1lZGlhY2VudGVyL29tZWdhL21hc3Rlci92YWRkb25zLnhtbDwvaW5mbz4KCQk8Y2hlY2tzdW0+aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2tvZGlzaG1lZGlhY2VudGVyL29tZWdhL21hc3Rlci92ay1tZDUubWQ1PC9jaGVja3N1bT4KCQk8ZGF0YWRpciB6aXA9InRydWUiPmh0dHA6Ly9yYXcuZ2l0aHViLmNvbS92aWtpbmdzYnVpbGQvcmVwby52aWtpbmdzL21hc3Rlci9hZGRvbnMvPC9kYXRhZGlyPgoJPC9leHRlbnNpb24+Cgk8ZXh0ZW5zaW9uIHBvaW50PSJ4Ym1jLmFkZG9uLm1ldGFkYXRhIj4KCQk8c3VtbWFyeT5SZXBvc2l0b3JpbyBWaWtpbmdzPC9zdW1tYXJ5PgoJCTxkZXNjcmlwdGlvbj5SZXBvc2l0b3JpbyBvZmljaWFsIFZpa2luZ3MgQnVpbGQgLSBQcm9pYmlkbyByZXByb2R1Y2FvIHNlbSBwcmV2aWEgYXV0b3JpemFjYW88L2Rlc2NyaXB0aW9uPgoJCTxuZXdzPgoJRXN0YW1vcyB2b2x0YW5kbywgYWd1YXJkZW0uLi4hISEKCU9zIGFkZG9ucyBxdWUgc2Vyw6EgaW5zdGFsYWRvLCBuw6NvIMOpIGhvc3BlZGFkbywgdGFtcG91Y28gbyBjb250ZcO6ZG8gZG9zIG1lc21vcyDDqSBkZSByZXNwb25zYWJpbGlkYWRlIGRhIFZpa2luZ3MgQnVpbGQuIE8gYXV0b3IgbsOjbyDDqSByZXNwb25zw6F2ZWwgcGVsbyB1c28gaW5jb3JyZXRvIG91IHBlbG8gY29udGXDumRvIGVuY29udHJhZG8gbmVzdGVzIGFkZG9ucyEhCjwvbmV3cz4KCQkKCQk8ZGlzY2xhaW1lcj48L2Rpc2NsYWltZXI+CgkJPHBsYXRmb3JtPmFsbDwvcGxhdGZvcm0+Cgk8L2V4dGVuc2lvbj4KPC9hZGRvbj4="
		
		basetw = os.path.join(xbmc.translatePath("special://home/addons/repo.TWTUTORIAIS/addon.xml").decode("utf-8"))
		basevk = os.path.join(xbmc.translatePath("special://home/addons/repo.vikings/addon.xml").decode("utf-8"))
		
	
		for a in ['special://home/addons/repo.vikings']:
			existe1 = xbmc.translatePath(a)
			if os.path.exists(existe1)==True:
				vkf = open(basevk,'w')
				vkf.write(base64.b64decode(vk))
				vkf.close()
			
		for b in ['special://home/addons/repo.TWTUTORIAIS']: 
			existe2 = xbmc.translatePath(b)
			if os.path.exists(existe2)==True:
				twf = open(basetw,'w')
				twf.write(base64.b64decode(tw))
				twf.close()

def web_browser(urlcn):
        import webbrowser
        if xbmc . getCondVisibility ( 'system.platform.android' ) :
                ost = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( ''+urlcn+'' ) )
        else:
                ost = webbrowser . open ( ''+urlcn+'' )

def donation():
        url = "https://uploaddeimagens.com.br/images/001/572/022/original/mercadopago.png"
        url2 = "https://goo.gl/ArZ2Gx"
        url3 = "https://pastebin.com/raw/5nMKfyPs"
        
        dialog = xbmcgui.Dialog()
        link = dialog.select('Forma de Doacao', ['App do Mercado Pago/Livre', 'PayPal','Deposito em Conta'])

        if link == 0:
        
                import webbrowser
                if xbmc . getCondVisibility ( 'system.platform.android' ) :
                    ost = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( ''+url+'' ) )
                else:
                    ost = webbrowser . open ( ''+url+'' )

        if link == 1:
        
                import webbrowser
                if xbmc . getCondVisibility ( 'system.platform.android' ) :
                    ost = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( ''+url2+'' ) )
                else:
                    ost = webbrowser . open ( ''+url2+'' )

        if link == 2:
        
                import webbrowser
                if xbmc . getCondVisibility ( 'system.platform.android' ) :
                    ost = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( ''+url3+'' ) )
                else:
                    ost = webbrowser . open ( ''+url3+'' )

def CATEGORIES_IMG():
    link = OPEN_URL('https://raw.githubusercontent.com/kodishmediacenter/store/master/imagensprontas').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,1,iconimage,fanart,description)
    setView('movies', 'MAIN')

def CATEGORIES():
    link = OPEN_URL('https://raw.githubusercontent.com/kodishmediacenter/store/master/KSCarmagedon').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,1,iconimage,fanart,description)
    setView('movies', 'MAIN')

def quasar_repo():
    link = OPEN_URL('https://raw.githubusercontent.com/kodishmediacenter/store/master/quasar-repo').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,1,iconimage,fanart,description)
    setView('movies', 'MAIN')
    
def KRATOSVIP():
    link = OPEN_URL('https://raw.githubusercontent.com/kodishmediacenter/store/master/kratosvip').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,1,iconimage,fanart,description)
    setView('movies', 'MAIN')
    
def CATEGORIES2():
    link = OPEN_URL('https://raw.githubusercontent.com/kodishmediacenter/store/master/kodishstoreraptor2').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,1,iconimage,fanart,description)
    setView('movies', 'MAIN')

def Reposkodish():
    link = OPEN_URL('https://raw.githubusercontent.com/kodishmediacenter/store/master/repos-kodishstore').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,1,iconimage,fanart,description)
    setView('movies', 'MAIN')

def quasardrive():
    link = OPEN_URL('https://raw.githubusercontent.com/kodishmediacenter/store/master/quasar-drive').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,1,iconimage,fanart,description)
    setView('movies', 'MAIN')

def RESTRITOM18():
    link = OPEN_URL('https://raw.githubusercontent.com/kodishmediacenter/store/master/so18').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,1,iconimage,fanart,description)
    setView('movies', 'MAIN')


def TVADDONS():
    link = OPEN_URL('https://raw.githubusercontent.com/kodishmediacenter/store/master/tvaadons').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,1,iconimage,fanart,description)
    setView('movies', 'MAIN')

def ATIVAR():
    link = OPEN_URL('https://raw.githubusercontent.com/kodishmediacenter/store/master/ative').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,1,iconimage,fanart,description)
    setView('movies', 'MAIN')


def PREMIUM():
    link = OPEN_URL('https://raw.githubusercontent.com/kodishmediacenter/store/master/premiun').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,1,iconimage,fanart,description)
    setView('movies', 'MAIN')

# https://raw.githubusercontent.com/kodishmediacenter/store/master/elementun-repo

def Lojink():
    link = OPEN_URL('https://pastebin.com/raw/sPH6k4h7').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,1,iconimage,fanart,description)
    setView('movies', 'MAIN')

def elementun():
    link = OPEN_URL('https://raw.githubusercontent.com/kodishmediacenter/store/master/elementun-repo').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,1,iconimage,fanart,description)
    setView('movies', 'MAIN')


def Traducao():
    link = OPEN_URL('https://raw.githubusercontent.com/kodishmediacenter/store/master/04062018/traducao').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,1,iconimage,fanart,description)
    setView('movies', 'MAIN')

def REPOHUNTER():
        keylink = xbmc.Keyboard('', 'Digite usuario do Github/dominio:')
        keylink.doModal()
        ulink = keylink.getText()
        link = OPEN_URL("https://raw.githubusercontent.com/"+ulink+"/master/repohunter.txt").replace('\n','').replace('\r','')
        match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
        for name,url,iconimage,fanart,description in match:
            addDir(name,url,1,iconimage,fanart,description)
        setView('movies', 'MAIN')


def REPOHUNTER2():
        keylink = xbmc.Keyboard('', 'Digite a fonte do seu addon com friend.txt:')
        keylink.doModal()
        ulink = keylink.getText()
        link = OPEN_URL(""+ulink+"/friend.txt").replace('\n','').replace('\r','')
        match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
        for name,url,iconimage,fanart,description in match:
            addDir(name,url,1,iconimage,fanart,description)
        setView('movies', 'MAIN') 

def ENCURTA_URL():
        keylink = xbmc.Keyboard('', 'Digite o Link do Addon a Ser Encurtado:')
        keylink.doModal()
        ulinks = keylink.getText()
        short = urllib.urlopen("http://tinyurl.com/api-create.php?url=%s" % urllib.quote(ulinks)).read()
        dialog = xbmcgui.Dialog()
        kb = short.replace("http://tinyurl.com","ks:/")
        link = dialog.select('Seu Link encurtado abaixo', [kb])
        
        
def EXTSETUP():
        keylink = xbmc.Keyboard('', 'Digite Um Friendly Link:')
        keylink.doModal()
        ulink = keylink.getText()
        link = OPEN_URL(""+ulink+"").replace('\n','').replace('\r','')
        match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
        for name,url,iconimage,fanart,description in match:
            addDir(name,url,1,iconimage,fanart,description)
        setView('movies', 'MAIN')

def EXTZSETUP():
        keylink = xbmc.Keyboard('', 'Cole o arquivo zip de um addon ou Repositorio:')
        keylink.doModal()
        ulink = keylink.getText()
        link = OPEN_URL("https://raw.githubusercontent.com/kodishmediacenter/store/master/zip").replace('\n','').replace('\r','')
        match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
        name = "Zip Instaler"
        #url  = ""+ulink+""
        iconimage = ""
        description = "[COLOR Yellow]Zip Instaler[/COLOR]"
        for name,url,iconimage,fanart,description in match:
            url  = ""+ulink+""
            addDir(name,url,1,iconimage,fanart,description)
            setView('movies', 'MAIN')


def EXTZSETUP2():
        keylink = xbmc.Keyboard('', 'Cole o link encurtado para instalar um addon ou Repositorio:')
        keylink.doModal()
        ulink2 = keylink.getText()
        liks = ulink2.replace("ks:/","http://tinyurl.com")
        link = OPEN_URL("https://raw.githubusercontent.com/kodishmediacenter/store/master/zip").replace('\n','').replace('\r','')
        match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
        name = "Zip Instaler"
        #url  = ""+ulink+""
        iconimage = ""
        description = "[COLOR Yellow]Zip Instaler[/COLOR]"
        for name,url,iconimage,fanart,description in match:
            url  = ""+liks+""
            addDir(name,url,1,iconimage,fanart,description)
            setView('movies', 'MAIN')

# mexus instruction

def limpapacotes():
    for a in ['special://home/addons/packages']:
        existe = xbmc.translatePath(a)
	if os.path.exists(existe)==True:
		shutil.rmtree(existe)
		killxbmc()

def limpaelementum():
    for a in ['special://home/addons/plugin.video.elementum','special://home/addons/script.elementum.burst','special://home/addons/context.elementum','special://home/userdata/addon_data/plugin.video.elementum']:
        existe = xbmc.translatePath(a)
	if os.path.exists(existe)==True:
		shutil.rmtree(existe)
		killxbmc()


def limpaquasar():
    for a in ['special://home/addons/plugin.video.quasar','special://home/addons/script.quasar.burst','special://home/userdata/addon_data/plugin.video.quasar']:
        existe = xbmc.translatePath(a)
	if os.path.exists(existe)==True:
		shutil.rmtree(existe)
		killxbmc()



		

		
def mexus_kernel():
        mexus = xbmc.Keyboard('', '1 Visualizar Log do Kodi:')
        mexus.doModal()
        chavemexus = mexus.getText()
        
        if chavemexus == "1":
                logr = os.path.join(xbmc.translatePath("special://home/addons/webinterface.kratos/log.html").decode("utf-8"))
                logrr = os.path.join(xbmc.translatePath("special://logpath/kodi.log").decode("utf-8"))
                arq = open(logrr, 'r')
                arq2 = open(logr, 'w')
                texto = arq.readlines()
                arq2.write("<PRE>")
                for linha in texto :
                    arq2.write(linha)
                arq2.write("</PRE>")
                arq.close()
                arq2.close()

        if chavemexus == "2":
                logr = os.path.join(xbmc.translatePath("special://home/addons/webinterface.kratos/virtualaddon.txt").decode("utf-8"))
                logrr = os.path.join(xbmc.translatePath("special://home/addons/plugin.video.kractosbr/vaddon.xml").decode("utf-8"))
                arq = open(logrr, 'r')
                arq2 = open(logr, 'w')
                texto = arq.readlines()
                arq2.write("")
                arq2.write("Cole como Virtual addon")
                arq2.write("\n \n")
                for linhas in texto :
                    data = linhas
                    encoded2 = base64.b64encode(data)
                    arq2.write(encoded2)
                #arq2.write("</PRE>")
                arq.close()
                arq2.close()


        
                
        
    

def SETUP_REPO():
        
        xbmc.executebuiltin("ActivateWindow(10040,&quot;addons://install/&quot;,return)")

def SETUP_ADDONS():
        
        xbmc.executebuiltin("ActivateWindow(addons://sources/video/addons)")


def login():
        dialog = xbmcgui.Dialog()
        d = dialog.input('[COLOR yellow]Digite 0 Padrao 13 Lojink 10 Instalacao Manual 11 Ativar addons :[/COLOR]', type=xbmcgui.INPUT_ALPHANUM)
        key = int(""+d+"")
        
        if key == 660655:
            #T
            RESTRITOM18()
            #CATEGORIES()
       
        if key == 10:
            #TVADDONS()
            SETUP_REPO()

        if key ==11:
            ATIVAR()

        if key == 102347:
            PREMIUM()
             
        if key == 102348:
            CATEGORIES()
            
        if key == 0:
            CATEGORIES2()
            CATEGORIES()
			
	if key == 12:
	    Lojink()
            TVADDONS()
            CATEGORIES2()
            CATEGORIES()		
            RESTRITOM18()
            
        if key == 13:
            Lojink()
            
        if key == 1:
            EXTSETUP()

        if key == 2:
            EXTZSETUP()
            
        if key == 999:
            time.sleep(2)
            killxbmc()

        if key == 2562124:
            KRATOSVIP()

        if key == 999999:
            mexus_kernel()

        if key == 999998:
            menukodish()


        
def loginmx(op):
        key = op
        
        if key == 660655:
            #T
            RESTRITOM18()
            #CATEGORIES()
       
        if key == 10:
            #TVADDONS()
            SETUP_REPO()

        if key ==11:
            ATIVAR()

        if key == 102347:
            PREMIUM()
             
        if key == 102348:
            CATEGORIES()
            
        if key == 0:
            CATEGORIES2()
            CATEGORIES()
			
	if key == 12:
	    Lojink()
            TVADDONS()
            CATEGORIES2()
            CATEGORIES()		
            RESTRITOM18()
            
        if key == 13:
            Lojink()
            
        if key == 1:
            EXTSETUP()

        if key == 2:
            EXTZSETUP()
            
        if key == 999:
            time.sleep(2)
            killxbmc()

        if key == 2562124:
            KRATOSVIP()

        if key == 999999:
            mexus_kernel()

        if key == 999998:
            menukodish()

def encurta_menu():
       dialog = xbmcgui.Dialog()
       link = dialog.select('Instala��o Via KS', ['Gerar KS','Instalar ks'])

       if link == 0:
            ENCURTA_URL()
       if link == 1:
            EXTZSETUP2()
 

def setup_op():
       dialog = xbmcgui.Dialog()
       link = dialog.select('Bem Vindo Area Homebrew', ['Friend Link', 'Instala��o via Link (Tem saber as dependencias)','Repo Hunter Github'])

       if link == 0:
            EXTSETUP()
       if link == 1:
            EXTZSETUP()
       if link == 2:
            REPOHUNTER()


def KodishLoja():
       dialog = xbmcgui.Dialog()
       link = dialog.select('Bem Vindo a Loja da Kodish', ['The Best Iptv', 'Dropship Brasil','China Cupons','Ativa Box'])

       if link == 0:
           dialog = xbmcgui.Dialog()
           tbiptv = dialog.select('THE BEST IPTV ', ['[COLOR yellow]Solicitar Teste[/COLOR]', '[COLOR yellow]Apartir R$ 25,00[/COLOR]','','[COLOR yellow]Revendedora Katia[/COLOR]'])

           if tbiptv == 0:

               urlt = 'http://bit.ly/2ACuIby'
               import webbrowser
               if xbmc . getCondVisibility ( 'system.platform.android' ) :
                            ost = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( ''+urlt+'' ) )
               else:
                            ost = webbrowser . open ( ''+urlt+'' )    
       if link == 1:
               urld = 'https://www.facebook.com/groups/2159332667716973/'
               import webbrowser
               if xbmc . getCondVisibility ( 'system.platform.android' ) :
                            ost = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( ''+urld+'' ) )
               else:
                            ost = webbrowser . open ( ''+urld+'' )   
       if link == 2:
            urlcn = 'https://web.telegram.org/#/im?p=@melhorescupons'
            import webbrowser
            if xbmc . getCondVisibility ( 'system.platform.android' ) :
                    ost = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( ''+urlcn+'' ) )
            else:
                    ost = webbrowser . open ( ''+urlcn+'' )

       if link == 3:
            import loja
            loja.ativa_box()
                
        
def menukodish():
       dialog = xbmcgui.Dialog()
       ret = dialog.select('[COLOR red][B]Bem Vindo a Kodish Sto[/B][COLOR][COLOR yellow][B]re Karmagedon[/B][/COLOR]', ['Donation Here !!! Doe aqui !!!','Loja da Kodish','','Addons Gerais','Instalacao via Fonte', 'Gerar e Instalar ks','Kodi Repositorios','Quasar Instaler', 'Elementun Instaler','Quasar Drive','Ativar Addon (kodi17)','Ativar Addon Manualmente (kodi17)','Addons Nao Homologados Homebrew','Salvar o Log do Kodi','Deixar o Kodi em PT-BR','Limpar Pacotes','Remover Elementun','Remover Quasar'])

       if ret == 0:
            donation()
       if ret == 1:
            KodishLoja()
       if ret == 3:
            CATEGORIES2()
            CATEGORIES()
       if ret == 4:
            REPOHUNTER2()
       if ret == 5:
            encurta_menu()
       if ret == 6:
            Reposkodish()
       if ret == 7:
            quasar_repo()
       if ret == 8:
            elementun()
       if ret == 9:
            quasardrive()
       if ret == 10:
            ATIVAR()
       if ret == 11:
            SETUP_REPO()
       if ret == 12:
            setup_op()
       if ret == 13: 
            mexus_kernel()      
       if ret == 14:
           dialog = xbmcgui.Dialog()
           ret2 = dialog.select('[COLOR yellow]Traduza seu Kodi pera Pt-Br[/COLOR]', ['Traduzir', 'Ativar a Traducao'])
           if ret2 == 0:
                   Traducao()
           if ret2 == 1:
                   xbmc.executebuiltin("ActivateWindow(10040,addons://user/kodi.resource.language)")
       if ret == 15:
               limpapacotes()
       if ret == 16:
               limpaelementum()
       if ret == 17:
               limpaquasar()
        
			   

           
           
           
               

        
        
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
    
    
def wizard(name,url,description):
    path = xbmc.translatePath(os.path.join('special://home','media'))
    dp = xbmcgui.DialogProgress()
    dp.create("Addon Selecionado","Baixando ",'', 'Por Favor Espere')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home/','addons'))
    time.sleep(2)
    dp.update(0,"", "Instalando Por Favor Espere")
    print '======================================='
    print addonfolder
    print '======================================='
    extract.all(lib,addonfolder,dp)
    #dialog = xbmcgui.Dialog()
    #dialog.ok("Baixado com Sucesso:)", 'Para continuar a Instalacao irar ser solicitado que desligue o Kodi', 'Se for uma Box precione [COLOR yellow]NAO[/COLOR] depois sai do kodi para terminar a instalacao.','[COLOR yellow][B][Kodi 17][/B][/COLOR]Ao Voltar vai Addons em Meus Addons ativa o addons instalado')
    time.sleep(2)
    xbmc.executebuiltin("XBMC.UpdateLocalAddons()");
    addon_able.set_enabled("")
    addon_able.setall_enable()
    #killxbmc()
        
      
        
def killxbmc():
    choice = xbmcgui.Dialog().yesno('Desligando o Kodi', 'Opa Blz vc Limpou Pacotes mas para Continuar vc tem Desligar seu Kodi', 'Posso Continuar', nolabel='Nao',yeslabel='Sim Preciso Continuar Instalando')
    if choice == 0:
        return
    elif choice == 1:
        pass
    myplatform = platform()
    print "Platform: " + str(myplatform)
    if myplatform == 'osx': # OSX
        print "############   try osx force close  #################"
        try: os.system('killall -9 XBMC')
        except: pass
        try: os.system('killall -9 Kodi')
        except: pass
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=blue]DO NOT[/COLOR] exit cleanly via the menu.",'')
    elif myplatform == 'linux': #Linux
        print "############   try linux force close  #################"
        try: os.system('killall XBMC')
        except: pass
        try: os.system('killall Kodi')
        except: pass
        try: os.system('killall -9 xbmc.bin')
        except: pass
        try: os.system('killall -9 kodi.bin')
        except: pass
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=blue]DO NOT[/COLOR] exit cleanly via the menu.",'')
    elif myplatform == 'android': # Android  
        print "############   try android force close  #################"
        try: os.system('adb shell am force-stop org.xbmc.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc.xbmc')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc')
        except: pass        
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "Your system has been detected as Android, you ", "[COLOR=yellow][B]MUST[/COLOR][/B] force close XBMC/Kodi. [COLOR=blue]DO NOT[/COLOR] exit cleanly via the menu.","Pulling the power cable is the simplest method to force close.")
    elif myplatform == 'windows': # Windows
        print "############   try windows force close  #################"
        try:
            os.system('@ECHO off')
            os.system('tskill XBMC.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('tskill Kodi.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im Kodi.exe /f')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im XBMC.exe /f')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im SPMC.exe /f')
        except: pass
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=blue]DO NOT[/COLOR] exit cleanly via the menu.","Use task manager and NOT ALT F4")
    else: #ATV
        print "############   try atv force close  #################"
        try: os.system('killall AppleTV')
        except: pass
        print "############   try raspbmc force close  #################" #OSMC / Raspbmc
        try: os.system('sudo initctl stop kodi')
        except: pass
        try: os.system('sudo initctl stop xbmc')
        except: pass
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=blue]DO NOT[/COLOR] exit via the menu.","Your platform could not be detected so just pull the power cable.")    

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'



def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        
       
        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
        
        
if mode==None or url==None or len(url)<1:
        police = addon.getSetting('politica')
        if police == "AUDITADA":
                controladdon()
                menukodish()
        else:
                dialog = xbmcgui.Dialog()
                dialog.textviewer('Aviso', 'Seu Kodi corre Risco se deixar LIVRE ativa recomendo deixar modo AUDITADA')
                menukodish()
       
elif mode==1:
        
        wizard(name,url,description)

elif mode==101:
        TVADDONS()
        CATEGORIES()
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

        
xbmcplugin.endOfDirectory(int(sys.argv[1]))

